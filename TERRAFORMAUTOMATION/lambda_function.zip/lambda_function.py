import json
import boto3
import os

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    try:
        # 🔧 Extract input based on integration type
        if 'body' in event:
            # Proxy integration (stringified JSON)
            body = json.loads(event['body'])
        elif 'tenant' in event:
            # Direct call or test event
            body = event
        else:
            # Non-proxy integration: params are under event['queryStringParameters'] or directly in event
            body = event

        tenant = body['tenant']
        username = body['username']
        filename = body['filename']

        bucket_name = f"{tenant.lower()}-{username.lower()}-storage"

        presigned_post = s3_client.generate_presigned_post(
            Bucket=bucket_name,
            Key=filename,
            Fields={"acl": "private"},
            Conditions=[
                {"acl": "private"},
                ["content-length-range", 0, 10485760]
            ],
            ExpiresIn=300
        )

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "*"
            },
            "body": json.dumps(presigned_post)
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({ "error": str(e) })
        }
